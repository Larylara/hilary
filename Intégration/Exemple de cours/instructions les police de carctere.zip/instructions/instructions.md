# Exercice dirigé: Fonts

## Fonts locales
Utiliser la police "Muli" (toutes les variantes) pour l'ensemble du document

## Google Font
Utiliser la police "Barriecito" pour les titres

## Font des icônes
Ajouter le lien vers Font Awesome
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css
Rechercher les icônes des réseaux sociaux